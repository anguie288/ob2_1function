//
//  main.m
//  sample
//
//  Created by Angela on 2020-04-05.
//  Copyright © 2020 angela. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface resultc:NSObject

- (int) result: (int)num1 anum2:(int)num2;

@end

@implementation resultc
- (int)result: (int)num1 anum2:(int)num2 {
    
    int result=num1+num2;
    NSLog(@"result value is : %d\n", result);
 
   return result;
}
@end



void greet (int count){
    
    for (int h = 0; h<count; h++){
        printf("greet one\n");
        printf("greet two\n");
    }
    
}

int main(int argc, const char * argv[]) {
    
    // loops lesson
    
    resultc *sample = [[resultc alloc] init];
       
    [sample result:4 anum2:5];
       
    
    
    greet(2);
    
    return 0;
}



